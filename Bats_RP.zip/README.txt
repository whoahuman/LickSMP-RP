БИТЫ НА МЕЧ — Bats_RP
================================

Что это: 4 разные биты, которые выглядят как меч. Пак НЕ заменяет меч —
он подменяет только ВНЕШНИЙ ВИД, поэтому удар, замах и прочность остаются
мечовыми. В руке бита держится ровно как меч (посадка ванильная).

БИТЫ
  1  деревянная
  2  деревянная с гвоздями
  3  железная
  4  бита жнеца — обсидиан, череп, светящиеся руны;
     текстура АНИМИРОВАННАЯ: руны пульсируют, глаза тлеют, по стволу бегут искры

КАК ВЫДАТЬ (1.21.4 и новее)
  1) Положите Bats_RP.zip в .minecraft/resourcepacks
  2) Настройки -> Ресурспаки: включите пак СПРАВА, затем Готово
  3) F3+T (перезагрузка ресурсов)

  Любой меч подойдёт: бита — это внешний вид меча.
    /give @s minecraft:netherite_sword[minecraft:item_model="minecraft:bats/bat_wooden"]
    /give @s minecraft:netherite_sword[minecraft:item_model="minecraft:bats/bat_nails"]
    /give @s minecraft:netherite_sword[minecraft:item_model="minecraft:bats/bat_iron"]
    /give @s minecraft:netherite_sword[minecraft:item_model="minecraft:bats/bat_reaper"]

  Заменить в команде netherite_sword на wooden_sword / iron_sword /
  diamond_sword — вид не изменится, изменятся только характеристики меча.

  Если пак не видно: проверьте список активных паков и нажмите F3+T.
  4-я бита анимируется сама, ничего включать не нужно.


ЧТО ДЕЛАЕТ ПАК
  assets/minecraft/models/item/bats/*.json    — геометрия (объёмные боксы)
  assets/minecraft/textures/item/bats/*.png   — текстуры (у 4-й — лента кадров + .mcmeta)
  assets/minecraft/items/bats/*.json          — item-дефиниции (1.21.4+)

МОДЕЛЬ МОЖНО ПОМЕНЯТЬ ПОД СЕБЯ
  * размер/наклон: в models/item/bats/bat_*.json у каждого элемента есть
    "rotation": {"origin": [2.2, 1.0, 8.0], "axis": "z", "angle": -45} —
    угол -45 ставит биту по диагонали, как спрайт меча (правило правой руки);
  * длину биты меняют координаты "from"/"to" у элементов bar1..bar3 и tip;
  * скорость анимации у 4-й биты: в bat_reaper.png.mcmeta "frametime": 3
    (3 = 3 тика на кадр; больше число — медленнее).

СОВМЕСТИМОСТЬ
  Пак трогает только свои файлы в models/item/bats, textures/item/bats,
  items/bats, поэтому спокойно работает вместе с TabBanner_RP, CoinsText_RP
  и BlockyStatues_RP.
